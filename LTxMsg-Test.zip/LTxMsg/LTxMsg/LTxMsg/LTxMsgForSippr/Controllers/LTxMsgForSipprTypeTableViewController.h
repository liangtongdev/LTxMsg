//
//  LTxMsgForSipprTypeTableViewController.h
//  LTxMsg
//
//  Created by liangtong on 2018/7/24.
//  Copyright © 2018年 LTx. All rights reserved.
//

#import <LTxCore/LTxCore.h>
/**
 * 消息类别预览
 **/
@interface LTxMsgForSipprTypeTableViewController : LTxCoreBaseTableViewController

@end
