//
//  ViewController.h
//  LTxMsg
//
//  Created by liangtong on 2018/7/23.
//  Copyright © 2018年 LTx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

